db = pd.read_csv("HW_gender.csv")

# create a pandas dataframe of ones for the bias term
ones_ = pd.DataFrame(np.ones(db.shape[0]))
ones_.columns = ['bias']
db = pd.concat([ones_, db], axis = 1)

y = db['Height']
X = db[['bias', 'Weight']]

# Linear Regression 
### Implement "loss" function
### Implement "fit" function gradient descent

def grad_descent(features, target, a, iterations = 50):

    """this function implements vectorized gradient descent
   using the following arguments:
   
   features - this is the dataset of features
   target - this is the target vector
   a - this is the learning rate
   iteraions - the iteratins of parameter updates

   n - this is the number of features
   m - this is the number of observations
   theta - these are the parameters, initialized to one by default"""

	n = features.shape[1]
	m = features.shape[0]
	theta = np.ones(n)

  # cost function

	cost_list = []


	for i in range(iterations):

		cost = 1/(2*m)*np.transpose((X@theta - y))@(X@theta - y)

		theta = theta - a*(1/m)*np.transpose(X)@(X@theta - y)
		cost_list.append(cost)

		return theta, cost_list

# linear regression with gradient descent
theta, cost_list = grad_descent(X, y, a = 0.0001)
print(cost_list)
